<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="card">

<div class="card-header" data-background-color="blue">
    <h1 class="title"><?= Html::encode($this->title) ?></h1>
    <p class="category">List of Users of the Evaluation</p>
    
</div>
<div style="margin: 20px">
    <!-- <p>
    <?= Html::a('Create User', ['create'], ['class' => 'btn btn-success']) ?>
    </p> -->
    <?php  echo $this->render('_search', ['model' => $searchModel]); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'tableOptions' => [
            'class' => 'table table-condensed',
        ],
        // 'filterModel' => $searchModel,
        'columns' => [

            // 'id',
            [ 'attribute' => 
                   'username', 
                   'label' => 'Username',
                   'format' => 'raw', 
                   'value' => 
                   function ($model) {
                   return Html::a($model->username, 
                   [ 'user/view', 'id' => $model->id ], [
                       'target' => '_blank']
                       );
                   },
                   'contentOptions' => [ 'style' => 'width: 40px' ],
               ],
            // 'holder',
            // 'password',
            // 'authkey',
            'roleName',
            'statusName',
            //'department',

            // ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>
