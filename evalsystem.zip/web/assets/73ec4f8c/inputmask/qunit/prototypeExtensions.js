/*

These are dummy prototype extensions to test that the inputmask code can deal with an extension

*/

Array.prototype.dummy = function(){
 	return false;
}

String.prototype.dummy = function(){
 	return false;
}
